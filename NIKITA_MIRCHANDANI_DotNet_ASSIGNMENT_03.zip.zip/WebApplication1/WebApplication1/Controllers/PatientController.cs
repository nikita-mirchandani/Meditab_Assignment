﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using System.Data;
using System.IO;
using System.Runtime.Intrinsics.Arm;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public PatientController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /*for getting all data*/
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
            select *
            from Patient where isdeleted = FALSE
        ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult((table));
        }
        /*INSERTING/CREATING  */
        [HttpPost]
        public JsonResult Insert(Patient pat)
        {
            string query = @"
               select generate_primary_key(@FIRST_NAME,@LAST_NAME,@MIDDLE_NAME,@DOB::date,@SEX)
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@FIRST_NAME", pat.first_name);
                    myCommand.Parameters.AddWithValue("@LAST_NAME", pat.last_name);
                    myCommand.Parameters.AddWithValue("@MIDDLE_NAME", pat.middle_name);
                    myCommand.Parameters.AddWithValue("@SEX", pat.sex);
                    myCommand.Parameters.AddWithValue("@DOB", pat.dob);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Added Successfully");
        }
        /*  UPDATION */
        [HttpPut("update")]
        public JsonResult updatePatient(Patient pat)
        {
            string query = @"
               select * from UpdateEntry(@Patient_id,@FIRST_NAME,@LAST_NAME,@MIDDLE_NAME,@SEX,@DOB::date)
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Patient_id", pat.Patient_id);
                    myCommand.Parameters.AddWithValue("@FIRST_NAME", pat.first_name);
                    myCommand.Parameters.AddWithValue("@LAST_NAME", pat.last_name);
                    myCommand.Parameters.AddWithValue("@MIDDLE_NAME", pat.middle_name);
                    myCommand.Parameters.AddWithValue("@SEX", pat._sex);
                    myCommand.Parameters.AddWithValue("@DOB", pat.dob);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }
            return new JsonResult("Updated Successfully!");
        }

        
        /*GETLIST USING SORTING AND PAGINATION*/
        [HttpGet("GetList")]
        public JsonResult GET(int? PageNumber = 1, int? PageSize = 10, string? orderby = "Patient.patient_id")
        {
            string query = @"
                select * FROM getlist(@PageNumber,@PageSize,@orderby);
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@PageNumber", PageNumber);
                    myCommand.Parameters.AddWithValue("@PageSize", PageSize);
                    myCommand.Parameters.AddWithValue("@orderby", orderby);

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult((table));
        }
        /* GET BY ID */
        [HttpGet("{id}")]
        public JsonResult GetByID(int id)
        {
            string query = @"
            select *
            from GetById(@Patient_id)
        ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Patient_id", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult((table));
        }
        /* delete by id*/
        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
              --  delete from Patient where PATIENT_ID=@Patient_id 
               SELECT * from DeleteEntry(@Patient_id);
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Patient_id", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Deleted Successfully");
        }
    }
}

