﻿using Microsoft.VisualBasic;

namespace WebApplication1.Models
{
    public class Patient
    {
        public int Patient_id { get; set; } 
        public string first_name { get; set;} = "";
        public string last_name { get; set; } = "";
        public string middle_name { get; set;} = "";
        public DateTime dob { get; set; } 
        public int sex { get; set; }
        public string _sex { get; set; } = "";    
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public string orderby { get; set; } = "Patient.patient_id";

    } 
}
